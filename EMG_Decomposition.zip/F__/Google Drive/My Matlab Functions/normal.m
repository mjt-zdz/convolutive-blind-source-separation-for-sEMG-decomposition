function vector = normal(v)
    
    vector = v/norm(v);
    
end